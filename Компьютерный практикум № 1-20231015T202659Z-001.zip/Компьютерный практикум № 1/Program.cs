﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Компьютерный_практикум___1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Задача 1.Соответствие номера из таблицы Unicode символу
            //for (int i= 0;i<= 256;i++)
            //{
            //    Console.WriteLine($"Код {i} соответствует символу {(char)i}");
            //}

            //Задача 2.Дан символ.Вывести его код
            //Console.Write("Введите символ:");
            //char ch = char.Parse(Console.ReadLine());
            //Console.WriteLine($"Символ {ch} имеет код {(int)ch}");

            //Задача 3.Дан символ.Вывести символ, который в кодовой таблице ASCII следует за этим символом
            //Console.Write("Введите символ:");
            //char ch = char.Parse(Console.ReadLine());
            //int code = (int)ch;
            //Console.WriteLine($"За символом {ch} следует символ {(char)(code+1)}");

            //Задача 4.Дан символ.Вывести два символа, стоящие перед ним в кодовой таблице ASCII
            //Console.Write("Введите символ:");
            //char ch = char.Parse(Console.ReadLine());
            //int code = (int)ch;
            //Console.WriteLine($"Перед символом {ch} предшествуют символы {(char)(code - 1)} и {(char)(code - 2)}");

            //Задача 5.Дан символ.Вывести два символа, первый из которых предшествует введенному символу в кодовой таблице, а второй – следует после него
            //Console.Write("Введите символ:");
            //char ch = char.Parse(Console.ReadLine());
            //int code = (int)ch;
            //Console.WriteLine($"Символу {ch} предшествует символ {(char)(code-1)}, следует символ {(char)(code+1)}");

            //Задача 6.Дано название футбольного клуба.Напечатать его на экране «столбиком»
            //Console.Write("Введите название клуба:");
            //string ch =Console.ReadLine();
            //char[] omas = ch.ToCharArray();
            // for(int i=0;i<omas.Length;i++)
            //{
            //    Console.WriteLine(i);
            //}

            //Задача 7.Составить программу, которая печатает заданное слово, начиная с последней буквы
            //Console.Write("Введите слово:");
            //string ch = Console.ReadLine();
            //char[] omas = ch.ToCharArray();
            //for (int i=omas.Length-1;i>=0;i--)
            //{
            //    Console.Write(omas[i]);
            //}

            //Задача 8.Преобразовать символы в строке из строчных в прописные и обратно
            //Console.Write("Введите строку:");
            //string stroka = Console.ReadLine();
            //char[] ch = stroka.ToCharArray();
            // for(int i=0;i<ch.Length;i++)
            //{
            //    Console.Write(char.ToUpper(ch[i]));
            //}
            //Console.WriteLine();
            // for (int i = 0; i < ch.Length; i++)
            //{
            //    Console.Write(char.ToLower(ch[i]));
            //}

            //Console.ReadKey();
        }
    }
}
